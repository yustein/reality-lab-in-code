Reality Lab in Code - Companion Snippets

Folder layout:
  code/
    001_*.py ... numbered snippet files (auto-generated)
    run_all.py  - executes snippets in order in a shared namespace (so chapter examples can build step-by-step)

  manifest.json - index -> file -> source section mapping

How to run:
  1) Create and activate a virtual environment (recommended)
  2) Install dependencies:
       pip install numpy matplotlib pandas
     (Some snippets may also use scipy if you add those later.)
  3) Run:
       python code/run_all.py

Notes:
  - Matplotlib uses the Agg backend so the runner works headlessly.
  - If you later edit the manuscript, regenerate this folder to keep it in sync.
