# Auto-generated companion snippet
# Source section: Chapter 31 - Oscillations in Health and Medicine
# Paragraphs: 5375-5377
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

numerator = sensitivity * prior
denominator = numerator + false_positive * (1 - prior)
posterior = numerator / denominator
print("Probability of disease given positive test:", posterior)
