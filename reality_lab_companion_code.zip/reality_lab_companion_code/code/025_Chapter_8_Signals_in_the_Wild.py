# Auto-generated companion snippet
# Source section: Chapter 8 - Signals in the Wild
# Paragraphs: 1815-1819
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Type: conda activate realitylab (if needed)
import numpy as np
