# Auto-generated companion snippet
# Source section: Chapter 29 - Building Reality Labs: Projects That Teach
# Paragraphs: 5002-5009
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 2000)
heartbeat = np.sin(2*np.pi*1.2*t) ** 8
heartbeat += 0.05*np.random.normal(0, 1, len(t))
plt.plot(t, heartbeat)
plt.title("Simulated Heartbeat Signal")
plt.xlabel("Time")
plt.ylabel("Amplitude")
plt.show()
peaks = []
for i in range(1, len(heartbeat)-1):
    if heartbeat[i] > heartbeat[i-1] and heartbeat[i] > heartbeat[i+1] and heartbeat[i] > 0.5:
        peaks.append(i)
        plt.plot(t, heartbeat)
        plt.scatter(t[peaks], heartbeat[peaks])
        plt.title("Heartbeat Peaks Detected")
        plt.show()
