# Auto-generated companion snippet
# Source section: Appendix B: Math Minimalism
# Paragraphs: 7499-7500
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

y_low = np.sin(1*t)
y_high = np.sin(5*t)
plt.plot(t, y_low, label="low frequency")
plt.plot(t, y_high, label="high frequency")
plt.legend()
plt.show()
