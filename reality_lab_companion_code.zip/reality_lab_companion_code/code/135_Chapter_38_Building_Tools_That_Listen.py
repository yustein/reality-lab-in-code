# Auto-generated companion snippet
# Source section: Chapter 38 - Building Tools That Listen
# Paragraphs: 6272-6286
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np


freq2 = 0.051  # default frequency increment per step
freq1 = 0.05  # default frequency increment per step
coupling = 0.01  # default coupling strength

def coupled(freq1, freq2, coupling, steps=200):
    phase1 = 0.0
    phase2 = 1.0
    history = []

    for step in range(steps):
        phase1 += freq1 + coupling*(phase2 - phase1)
        phase2 += freq2 + coupling*(phase1 - phase2)

        history.append((phase1, phase2))

        return np.array(history)
        data = coupled(freq1=0.2, freq2=0.21, coupling=0.05)
        import matplotlib.pyplot as plt

        plt.plot(data[:,0], label="Oscillator 1")
        plt.plot(data[:,1], label="Oscillator 2")
