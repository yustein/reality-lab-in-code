#!/usr/bin/env python3
"""Run every snippet in this folder in order (shared state).

The manuscript often builds examples step-by-step. To match that experience,
this runner executes each snippet file in the same Python process, so variables
defined in earlier snippets are available to later ones.

It stops at the first failure and prints the failing file plus a traceback.
"""

import os
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.environ.setdefault("MPLBACKEND", "Agg")

def main() -> int:
    files = sorted(p for p in HERE.glob("*.py") if p.name != "run_all.py" and p.name[0:3].isdigit())
    if not files:
        print("No snippet files found.")
        return 2

    # Shared execution namespace across snippets
    ns = {"__name__": "__main__"}

    print(f"Running {len(files)} snippet files (shared state)...")
    for i, path in enumerate(files, start=1):
        print(f"{i:03d}/{len(files):03d} -> {path.name}")
        try:
            code = path.read_text(encoding="utf-8")
            exec(compile(code, str(path), "exec"), ns, ns)
        except Exception:
            print("\nFAILED:", path.name)
            traceback.print_exc()
            return 1

    print("\nAll snippets executed successfully.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
