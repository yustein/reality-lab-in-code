# Auto-generated companion snippet
# Source section: Chapter 5 - Resonance and Collapse
# Paragraphs: 1322-1326
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Type: conda activate realitylab (if needed)
# Type: jupyter notebook
import numpy as np
import matplotlib.pyplot as plt
