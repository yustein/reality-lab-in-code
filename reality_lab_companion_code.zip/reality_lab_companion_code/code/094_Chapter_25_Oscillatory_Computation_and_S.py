# Auto-generated companion snippet
# Source section: Chapter 25 - Oscillatory Computation and Signal Machines
# Paragraphs: 4410-4418
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 500)
signal = np.sin(t) + 0.4*np.random.normal(0, 1, 500)
window = 20
low_pass = np.convolve(signal, np.ones(window)/window, mode="same")
plt.plot(signal, alpha=0.3, label="Raw")
plt.plot(low_pass, label="Low-pass filtered")
plt.legend()
plt.title("Low-Pass Filter: Slow Structure Revealed")
plt.show()
high_pass = signal - low_pass
plt.plot(high_pass)
plt.title("High-Pass Filter: Fast Variation Only")
plt.show()
