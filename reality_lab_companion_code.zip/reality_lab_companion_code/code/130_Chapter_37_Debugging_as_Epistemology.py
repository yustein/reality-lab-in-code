# Auto-generated companion snippet
# Source section: Chapter 37 - Debugging as Epistemology
# Paragraphs: 6093-6098
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import numpy as np

x = np.linspace(0, 10, 100)
print("First 5 values:", y[:5])
plt.plot(x, y)
plt.title("Inspecting a Signal")
plt.show()
