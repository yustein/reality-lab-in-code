# Auto-generated companion snippet
# Source section: Appendix B: Math Minimalism
# Paragraphs: 7518-7521
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

y = exp(k*t)
k = 0.3
y = np.exp(k*t)
plt.plot(t, y)
plt.title("Exponential Growth")
plt.show()
