# Auto-generated companion snippet
# Source section: Chapter 31 - Oscillations in Health and Medicine
# Paragraphs: 5328-5336
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 2000)
pulse = np.sin(2*np.pi*1.2*t) ** 8
pulse += 0.05*np.random.normal(0, 1, len(t))
plt.plot(t, pulse)
plt.title("Simulated Pulse Signal")
plt.xlabel("Time")
plt.ylabel("Amplitude")
plt.show()
breath = np.sin(2*np.pi*0.25*t)
plt.plot(t, breath)
plt.title("Simulated Breathing Oscillation")
plt.show()
activity = np.sin(2*np.pit/24) + 0.2*np.random.normal(0,1,len(t))
plt.plot(activity[:500])
plt.title("Toy Daily Activity Oscillation")
plt.show()
