# Auto-generated companion snippet
# Source section: Chapter 14 - The Oscillating Brain and Learning Systems
# Paragraphs: 2774-2776
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 2, 500)
signal1 = np.sin(2*np.pi*8*t)
signal2 = np.sin(2*np.pi*8*t + 1)
plt.plot(t, signal1, label="Network A")
plt.plot(t, signal2, label="Network B (Phase shifted)")
plt.legend()
plt.title("Phase Relationships in Brain Networks")
plt.show()
