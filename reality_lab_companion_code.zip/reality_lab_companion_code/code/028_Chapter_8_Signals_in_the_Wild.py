# Auto-generated companion snippet
# Source section: Chapter 8 - Signals in the Wild
# Paragraphs: 1894-1898
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 20, 500)
raw = np.sin(t) + 0.4*np.random.normal(0, 1, 500)
window = 15
clean = np.convolve(raw, np.ones(window)/window, mode="same")
plt.plot(raw, alpha=0.3, label="Raw")
plt.plot(clean, label="Cleaned")
plt.legend()
plt.title("Signal Pipeline: Raw to Clean")
plt.show()
