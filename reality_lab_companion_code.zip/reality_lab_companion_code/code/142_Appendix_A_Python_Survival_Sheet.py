# Auto-generated companion snippet
# Source section: Appendix A: Python Survival Sheet
# Paragraphs: 7264-7264
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

print("Hello, Reality Lab")
