# Auto-generated companion snippet
# Source section: Chapter 38 - Building Tools That Listen
# Paragraphs: 6253-6264
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")

def feedback_system(gain, steps=100):
    target = 1.0
    state = 0.0
    history = []
    for step in range(steps):
        error = target - state
        state += gain * error
        history.append(state)
        import matplotlib.pyplot as plt

        for gain in [0.1, 0.5, 1.2]:
            plt.legend()
            plt.title("Feedback Simulator: Stability vs Overshoot")
            plt.xlabel("Step")
            plt.ylabel("State")
            plt.show()
