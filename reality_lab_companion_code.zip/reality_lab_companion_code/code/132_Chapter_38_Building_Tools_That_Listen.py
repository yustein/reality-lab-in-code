# Auto-generated companion snippet
# Source section: Chapter 38 - Building Tools That Listen
# Paragraphs: 6219-6224
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

stream = np.sin(np.linspace(0, 20, 500)) + 0.3*np.random.normal(0,1,500)
def rolling_mean(data, window=20):
    return np.convolve(data, np.ones(window)/window, mode="same")
    smoothed = rolling_mean(stream)
    plt.plot(stream, alpha=0.3, label="Raw Stream")
    plt.plot(smoothed, label="Rolling Signal Monitor")
    plt.legend()
    plt.title("Signal Monitor: Listening to Oscillation")
    plt.show()
