# Auto-generated companion snippet
# Source section: Chapter 29 - Building Reality Labs: Projects That Teach
# Paragraphs: 5035-5052
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def predator_prey(prey_growth, predation, predator_death, predator_growth):
    prey = 10
    predator = 5
    prey_hist = []
    predator_hist = []

    for step in range(300):
        prey_change = prey_growth * prey - predation * prey * predator
        predator_change = predator_growth * prey * predator - predator_death * predator

        prey += 0.01 * prey_change
        predator += 0.01 * predator_change

        prey_hist.append(prey)
        predator_hist.append(predator)
        prey_hist, predator_hist = predator_prey(
        prey_growth=1.0,
        predation=0.1,
        predator_death=1.5,
        predator_growth=0.08
        )
        plt.plot(prey_hist, label="Prey")
        plt.plot(predator_hist, label="Predator")
        plt.legend()
        plt.title("Predator-Prey Oscillation Sandbox")
        plt.show()
