# Auto-generated companion snippet
# Source section: Chapter 6 - Coupled Oscillators: When Systems Lock Together
# Paragraphs: 1517-1517
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
