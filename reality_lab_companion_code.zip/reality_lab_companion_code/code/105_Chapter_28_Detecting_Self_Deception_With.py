# Auto-generated companion snippet
# Source section: Chapter 28 - Detecting Self-Deception With Code
# Paragraphs: 4895-4902
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

data = np.random.normal(5, 1, 200)
mean_original = np.mean(data)
import numpy as np

# Step 2: Perturb data with small noise
perturbed = data + np.random.normal(0, 0.1, len(data))
mean_perturbed = np.mean(perturbed)
print("Original mean:", mean_original)
print("Perturbed mean:", mean_perturbed)
