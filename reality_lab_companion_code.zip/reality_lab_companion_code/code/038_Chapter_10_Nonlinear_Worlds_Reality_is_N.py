# Auto-generated companion snippet
# Source section: Chapter 10 - Nonlinear Worlds: Reality is Not a Straight Line
# Paragraphs: 2273-2273
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Python is your laboratory for learning this.
