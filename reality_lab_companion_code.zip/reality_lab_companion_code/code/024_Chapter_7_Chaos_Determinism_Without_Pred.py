# Auto-generated companion snippet
# Source section: Chapter 7 - Chaos: Determinism Without Predictability
# Paragraphs: 1694-1699
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

steps = 200  # number of iterations
x1 = 0.5000  # initial condition A
x2 = 0.5001  # initial condition B (tiny perturbation)



r = 3.9  # default logistic-map parameter (chaotic regime)

history1 = []
history2 = []
for i in range(steps):
    x1 = r * x1 * (1 - x1)
    x2 = r * x2 * (1 - x2)
    history1.append(x1)
    history2.append(x2)
# plt.plot(history1, label="Initial x = 0.5000")
# plt.plot(history2, label="Initial x = 0.5001", linestyle="dashed")
# plt.legend()
# plt.title("Chaos: Tiny Difference Becomes Huge Divergence")
# plt.xlabel("Step")
# plt.ylabel("Value")
# plt.show()

plt.figure()
plt.plot(history1, label='Initial x = 0.5000')
plt.plot(history2, label='Initial x = 0.5001', linestyle='dashed')
plt.legend()
plt.title('Chaos: Tiny Difference Becomes Huge Divergence')
plt.xlabel('Step')
plt.ylabel('Value')
plt.tight_layout()
plt.show()
