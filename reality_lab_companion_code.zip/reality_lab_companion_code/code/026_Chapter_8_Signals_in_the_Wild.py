# Auto-generated companion snippet
# Source section: Chapter 8 - Signals in the Wild
# Paragraphs: 1836-1837
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

time = np.arange(0, 100)
temperature = 20 + 2*np.sin(0.1*time) + np.random.normal(0, 0.5, 100)
plt.plot(time, temperature)
plt.title("Temperature Signal Over Time")
plt.xlabel("Time")
plt.ylabel("Degrees (Simulated)")
plt.show()
