# Auto-generated companion snippet
# Source section: Chapter 30 - Time Series Forecasting Without Fantasy
# Paragraphs: 5176-5187
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

t = np.linspace(0, 20, 500)
signal = np.sin(t) + 0.3*np.random.normal(0, 1, 500)
plt.plot(signal)
plt.title("Example Time Series")
plt.show()
predictions = signal[:-1]
truth = signal[1:]
error = truth - predictions
print("Mean absolute error:", np.mean(np.abs(error)))
window = 10
moving_avg = np.convolve(signal, np.ones(window)/window, mode="same")
import matplotlib.pyplot as plt

plt.plot(signal, alpha=0.3, label="Raw")
