# Auto-generated companion snippet
# Source section: Chapter 4 - Oscillations Everywhere
# Paragraphs: 1206-1207
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 2, 500)
heartbeat = np.sin(2 * np.pi * 3 * t) ** 4
plt.plot(t, heartbeat)
plt.title("Heartbeat-Like Pulse Signal")
plt.xlabel("Time")
plt.ylabel("Pulse")
plt.show()
