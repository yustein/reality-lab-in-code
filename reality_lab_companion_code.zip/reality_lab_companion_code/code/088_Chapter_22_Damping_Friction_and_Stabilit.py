# Auto-generated companion snippet
# Source section: Chapter 22 - Damping, Friction, and Stability
# Paragraphs: 4040-4040
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

signal = np.exp(-0.05*t) * np.sin(2*np.pifreqt)
