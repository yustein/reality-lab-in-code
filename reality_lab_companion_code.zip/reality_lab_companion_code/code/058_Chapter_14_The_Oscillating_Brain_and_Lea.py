# Auto-generated companion snippet
# Source section: Chapter 14 - The Oscillating Brain and Learning Systems
# Paragraphs: 2736-2740
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Type: conda activate realitylab (if needed)
# Type: jupyter notebook
# Create a new notebook:
import numpy as np
import matplotlib.pyplot as plt
