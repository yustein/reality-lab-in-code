# Auto-generated companion snippet
# Source section: Chapter 1 - The World is a Waveform
# Paragraphs: 783-784
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

y1 = np.sin(t)
y2 = np.sin(t + 1)
plt.plot(t, y1, label="Wave 1")
plt.plot(t, y2, label="Wave 2 (shifted)")
plt.legend()
plt.show()
