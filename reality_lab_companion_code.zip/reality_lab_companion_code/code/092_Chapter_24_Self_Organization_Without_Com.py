# Auto-generated companion snippet
# Source section: Chapter 24 - Self-Organization Without Command
# Paragraphs: 4246-4246
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
