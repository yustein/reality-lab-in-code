# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2670-2677
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")

t = np.linspace(0, 20, 500)
import matplotlib.pyplot as plt
import numpy as np

focus = np.sin(0.5*t) + 0.3*np.random.normal(0, 1, 500)
plt.plot(t, focus)
plt.title("Attention as Rhythmic Pulse")
plt.xlabel("Time")
