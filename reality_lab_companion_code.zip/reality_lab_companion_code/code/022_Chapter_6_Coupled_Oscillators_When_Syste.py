# Auto-generated companion snippet
# Source section: Chapter 6 - Coupled Oscillators: When Systems Lock Together
# Paragraphs: 1587-1589
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

n = 20
phases = np.random.rand(n) * 2*np.pi
coupling = 0.05
history = []
for step in range(200):
    for i in range(n):
        interaction = 0
        for j in range(n):
            interaction += np.sin(phases[j] - phases[i])
            phases[i] += 1 + coupling * interaction / n
            history.append(phases.copy())
