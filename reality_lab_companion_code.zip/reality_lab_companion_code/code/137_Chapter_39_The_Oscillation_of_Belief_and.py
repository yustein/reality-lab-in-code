# Auto-generated companion snippet
# Source section: Chapter 39 - The Oscillation of Belief and Ideology
# Paragraphs: 6353-6353
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
