# Auto-generated companion snippet
# Source section: Chapter 4 - Oscillations Everywhere
# Paragraphs: 1235-1236
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 50, 500)
boom_bust = np.sin(0.3 * t) + 0.3 * np.random.normal(0, 1, 500)
plt.plot(t, boom_bust)
plt.title("Toy Boom-Bust Oscillation With Noise")
plt.xlabel("Time")
plt.ylabel("Market Mood Index")
plt.show()
