# Auto-generated companion snippet
# Source section: Chapter 42 - The Personal Reality Lab Practice
# Paragraphs: 6735-6737
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")

sleep = [7, 6.5, 8, 5.5, 7, 7.5, 6, 8, 7, 6, 7, 7.5, 6.5, 8]
import matplotlib.pyplot as plt
plt.plot(sleep, marker="o")
plt.title("Sleep Signal Over Two Weeks")
plt.xlabel("Day")
plt.ylabel("Hours")
plt.show()
