# Auto-generated companion snippet
# Source section: Chapter 17 - Bayesian Updating as Oscillation
# Paragraphs: 3272-3274
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

history = []
for step in range(20):
    evidence = np.random.choice([0, 1], p=[0.6, 0.4]) # noisy evidence
    belief = belief + evidence_strength * (evidence - belief)
    history.append(belief)
    plt.plot(history)
    plt.title("Belief Updated Over Time")
    plt.xlabel("Step")
    plt.ylabel("Belief Level")
    plt.show()
