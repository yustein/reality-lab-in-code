# Auto-generated companion snippet
# Source section: Chapter 14 - The Oscillating Brain and Learning Systems
# Paragraphs: 2757-2758
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 2, 500)
neural_rhythm = np.sin(2*np.pi*10*t)
plt.plot(t, neural_rhythm)
plt.title("Toy Neural Rhythm (10 Hz Oscillation)")
plt.xlabel("Time")
plt.ylabel("Electrical Activity")
plt.show()
