# Auto-generated companion snippet
# Source section: Chapter 23 - Phase Transitions in Code
# Paragraphs: 4129-4142
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 500)
pressure = t
threshold = 6
state = np.where(pressure < threshold, 0, 1)
plt.plot(t, state)
plt.title("Threshold Phase Transition")
plt.xlabel("Pressure")
plt.ylabel("System State")
plt.show()
state = 1 / (1 + np.exp(-(pressure - threshold)))
plt.plot(t, state)
plt.title("Soft Threshold Transition")
plt.xlabel("Pressure")
plt.ylabel("System State")
plt.show()
