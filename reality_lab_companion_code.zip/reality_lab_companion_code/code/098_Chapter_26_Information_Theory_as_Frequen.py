# Auto-generated companion snippet
# Source section: Chapter 26 - Information Theory as Frequency Discipline
# Paragraphs: 4579-4581
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

signal = np.tile([1,0,1,0], 250)
noise = np.random.choice([0,1], size=1000)
