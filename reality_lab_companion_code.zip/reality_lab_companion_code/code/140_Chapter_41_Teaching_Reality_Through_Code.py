# Auto-generated companion snippet
# Source section: Chapter 41 - Teaching Reality Through Code
# Paragraphs: 6622-6623
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

history = []
for step in range(50):
    error = target - state
    state += gain * error
    history.append(state)
