# Auto-generated companion snippet
# Source section: Chapter 30 - Time Series Forecasting Without Fantasy
# Paragraphs: 5198-5200
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

def autocorrelation(x, lag):
    return np.corrcoef(x[:-lag], x[lag:])[0,1]
    lags = range(1, 50)
    ac_values = [autocorrelation(signal, lag) for lag in lags]
    plt.plot(lags, ac_values)
    plt.title("Autocorrelation: Signal Memory Over Time")
    plt.xlabel("Lag")
    plt.ylabel("Correlation")
    plt.show()
