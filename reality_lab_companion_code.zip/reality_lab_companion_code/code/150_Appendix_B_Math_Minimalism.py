# Auto-generated companion snippet
# Source section: Appendix B: Math Minimalism
# Paragraphs: 7552-7553
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

trials = 10000
coin = np.random.choice([0,1], size=trials)
print("Mean outcome:", np.mean(coin))
