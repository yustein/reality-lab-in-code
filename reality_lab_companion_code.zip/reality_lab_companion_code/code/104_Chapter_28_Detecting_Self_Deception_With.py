# Auto-generated companion snippet
# Source section: Chapter 28 - Detecting Self-Deception With Code
# Paragraphs: 4859-4865
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 1, 20)
y = np.sin(2*np.pix) + np.random.normal(0, 0.3, len(x))
simple_fit = np.polyfit(x, y, 3)
complex_fit = np.polyfit(x, y, 15)
x_dense = np.linspace(0, 1, 200)
y_simple = np.polyval(simple_fit, x_dense)
y_complex = np.polyval(complex_fit, x_dense)
plt.scatter(x, y, label="Data")
plt.plot(x_dense, y_simple, label="Simple Fit")
plt.plot(x_dense, y_complex, label="Overfit Curve")
plt.legend()
plt.title("Overfitting: Noise Becomes False Structure")
plt.show()
