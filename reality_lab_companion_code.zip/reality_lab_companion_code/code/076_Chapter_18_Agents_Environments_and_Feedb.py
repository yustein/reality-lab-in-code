# Auto-generated companion snippet
# Source section: Chapter 18 - Agents, Environments, and Feedback
# Paragraphs: 3398-3414
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

history = []
for step in range(200):
    # Agent chooses randomly at first
    if np.random.rand() < 0.5:
        action = "left"
        reward = 1
        value_left += learning_rate * (reward - value_left)
    else:
        action = "right"
        reward = 3
        value_right += learning_rate * (reward - value_right)

        history.append((value_left, value_right))
        left_values = [h[0] for h in history]
        right_values = [h[1] for h in history]
        plt.plot(left_values, label="Value of Left Choice")
        plt.plot(right_values, label="Value of Right Choice")
        plt.legend()
        plt.title("Minimal Agent Learning Reward Values")
        plt.xlabel("Step")
        plt.ylabel("Estimated Value")
        plt.show()
