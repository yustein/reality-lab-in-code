# Auto-generated companion snippet
# Source section: Chapter 33 - Deep Learning as Signal Resonance
# Paragraphs: 5631-5634
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

target = 2.0
weight = -1.0
learning_rate = 0.1
history = []
for step in range(50):
    prediction = weight
    error = target - prediction
    weight += learning_rate * error
    history.append(weight)
    plt.plot(history)
    plt.title("Training as Feedback Tuning")
    plt.xlabel("Step")
    plt.ylabel("Weight Value")
    plt.show()
