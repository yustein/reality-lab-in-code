# Auto-generated companion snippet
# Source section: Chapter 15 - Measurement as Philosophy
# Paragraphs: 2918-2919
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

time_seconds = np.array([0, 1, 2, 3, 4])
distance_meters = np.array([0, 10, 20, 30, 40])
speed = distance_meters / time_seconds[1:]
