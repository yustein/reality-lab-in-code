# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2625-2627
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

history = []
for step in range(50):
    state = amplification * state
    history.append(state)
    plt.plot(history)
    plt.title("Anxiety Loop: Amplification Over Time")
    plt.xlabel("Step")
    plt.ylabel("Threat Signal Intensity")
    plt.show()
