# Auto-generated companion snippet
# Source section: Chapter 38 - Building Tools That Listen
# Paragraphs: 6302-6302
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

np.random.seed(42)
