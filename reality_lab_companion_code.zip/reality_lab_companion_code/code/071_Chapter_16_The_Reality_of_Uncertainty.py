# Auto-generated companion snippet
# Source section: Chapter 16 - The Reality of Uncertainty
# Paragraphs: 3132-3140
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Compute something repeatedly with noise.
import matplotlib.pyplot as plt
import numpy as np
history = []
for step in range(50):
    x = x * 1.05 + np.random.normal(0, 0.1)
    # history.append(x)
