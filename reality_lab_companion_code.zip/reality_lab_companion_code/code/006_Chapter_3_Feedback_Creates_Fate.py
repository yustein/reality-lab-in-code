# Auto-generated companion snippet
# Source section: Chapter 3 - Feedback Creates Fate
# Paragraphs: 1065-1070
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
population = 0.1
growth_rate = 1.2
steps = 50
history = []
for i in range(steps):

    growth_rate = 3.5  # default for logistic-style examples

    population = growth_rate * population * (1 - population)
    history.append(population)
