# Auto-generated companion snippet
# Source section: Chapter 17 - Bayesian Updating as Oscillation
# Paragraphs: 3260-3263
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

numerator = p_positive_given_disease * prior_disease
denominator = numerator + p_positive_given_no_disease * (1 - prior_disease)
posterior = numerator / denominator
print("Probability of disease given a positive test:", posterior)
