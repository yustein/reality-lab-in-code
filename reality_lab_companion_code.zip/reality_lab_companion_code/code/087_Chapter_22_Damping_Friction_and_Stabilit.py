# Auto-generated companion snippet
# Source section: Chapter 22 - Damping, Friction, and Stability
# Paragraphs: 4021-4024
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

signal_over = np.exp(-0.5*t)
import matplotlib.pyplot as plt

plt.plot(t, signal_over)
