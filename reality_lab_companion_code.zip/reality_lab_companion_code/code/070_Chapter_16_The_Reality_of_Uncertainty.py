# Auto-generated companion snippet
# Source section: Chapter 16 - The Reality of Uncertainty
# Paragraphs: 3117-3123
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

data = np.random.normal(5, 2, 1000)
mean = np.mean(data)
std = np.std(data)
print("Mean:", mean)
print("Standard deviation:", std)
stderr = std / np.sqrt(len(data))
lower = mean - 2*stderr
upper = mean + 2*stderr
print("Approximate 95% interval:", lower, "to", upper)
