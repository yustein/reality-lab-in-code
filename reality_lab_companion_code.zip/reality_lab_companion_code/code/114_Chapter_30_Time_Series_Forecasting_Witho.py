# Auto-generated companion snippet
# Source section: Chapter 30 - Time Series Forecasting Without Fantasy
# Paragraphs: 5212-5220
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# business cycles in economics
# If you ignore periodic forcing, forecasting fails.
import numpy as np

# Let us build a seasonal signal:
t = np.linspace(0, 100, 1000)
seasonal = np.sin(2*np.pit/20)
trend = 0.01*t
noise = 0.2*np.random.normal(0,1,len(t))
data = seasonal + trend + noise
plt.plot(data)
plt.title("Seasonal Oscillation + Trend")
plt.show()
