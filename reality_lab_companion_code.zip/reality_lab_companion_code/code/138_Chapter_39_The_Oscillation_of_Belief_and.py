# Auto-generated companion snippet
# Source section: Chapter 39 - The Oscillation of Belief and Ideology
# Paragraphs: 6387-6412
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

n = 200
opinions = np.random.uniform(-0.2, 0.2, n)
for step in range(100):
    new_opinions = opinions.copy()
    for i in range(1, n-1):
        local_mean = (opinions[i-1] + opinions[i] + opinions[i+1]) / 3
        new_opinions[i] += 0.1 * (local_mean - opinions[i])

        opinions = new_opinions
        plt.hist(opinions, bins=30)
        plt.title("Opinion Dynamics: Convergence Toward Attractors")
        plt.xlabel("Belief Value")
        plt.ylabel("Count")
        plt.show()
        opinions = np.random.uniform(-0.2, 0.2, n)
        for step in range(200):
            new_opinions = opinions.copy()
            for i in range(1, n-1):
                local_mean = (opinions[i-1] + opinions[i] + opinions[i+1]) / 3
                new_opinions[i] += 0.2 * (local_mean - opinions[i])

                # external polarization push
                import numpy as np

                new_opinions += 0.01 * np.sign(new_opinions)

                opinions = new_opinions
                plt.hist(opinions, bins=30)
                plt.title("Polarization Emerges Through Forcing")
                plt.show()
