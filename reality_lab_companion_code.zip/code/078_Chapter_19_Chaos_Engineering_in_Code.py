# Auto-generated companion snippet
# Source section: Chapter 19 - Chaos Engineering in Code
# Paragraphs: 3548-3555
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


r = 3.9  # default logistic-map parameter (chaotic regime)

def logistic(r, x):
    return r * x * (1 - x)
    history1 = []
    history2 = []
    for i in range(steps):
        x1 = logistic(r, x1)
        x2 = logistic(r, x2)
        history1.append(x1)
        history2.append(x2)
        plt.plot(history1, label="System 1")
        plt.plot(history2, linestyle="dashed", label="System 2 (Perturbed)")
        plt.legend()
        plt.title("Perturbation Experiment: Sensitivity Revealed")
        plt.xlabel("Step")
        plt.ylabel("Value")
        plt.show()
