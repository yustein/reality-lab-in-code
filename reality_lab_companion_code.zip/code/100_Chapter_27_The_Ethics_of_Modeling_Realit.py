# Auto-generated companion snippet
# Source section: Chapter 27 - The Ethics of Modeling Reality
# Paragraphs: 4724-4727
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

result = f(x)
window = 20
smoothed = np.convolve(signal, np.ones(window)/window, mode="same")
