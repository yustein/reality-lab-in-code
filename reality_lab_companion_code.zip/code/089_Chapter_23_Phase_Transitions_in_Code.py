# Auto-generated companion snippet
# Source section: Chapter 23 - Phase Transitions in Code
# Paragraphs: 4109-4109
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
