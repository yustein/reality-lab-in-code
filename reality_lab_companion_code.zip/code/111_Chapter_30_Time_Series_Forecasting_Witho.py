# Auto-generated companion snippet
# Source section: Chapter 30 - Time Series Forecasting Without Fantasy
# Paragraphs: 5155-5155
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
