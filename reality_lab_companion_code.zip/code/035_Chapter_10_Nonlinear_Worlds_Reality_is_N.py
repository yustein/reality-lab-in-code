# Auto-generated companion snippet
# Source section: Chapter 10 - Nonlinear Worlds: Reality is Not a Straight Line
# Paragraphs: 2195-2198
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


r = 3.9  # default logistic-map parameter (chaotic regime)

x = 0.2
history = []
for i in range(steps):
    x = r * x * (1 - x)
    history.append(x)
    plt.plot(history)
    plt.title("Nonlinear Dynamics: Logistic Map")
    plt.xlabel("Step")
    plt.ylabel("Value")
    plt.show()
