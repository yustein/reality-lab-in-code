# Auto-generated companion snippet
# Source section: Chapter 9 - Fourier Thinking: Hearing Frequencies Inside Everything
# Paragraphs: 2018-2030
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 2, 1000)
signal = np.sin(2*np.pi*5*t) + 0.5*np.sin(2*np.pi*20*t)
plt.plot(t, signal)
plt.title("Signal in Time Domain")
plt.xlabel("Time (seconds)")
plt.ylabel("Amplitude")
plt.show()
fft_values = np.fft.fft(signal)
fft_freqs = np.fft.fftfreq(len(signal), d=t[1]-t[0])
plt.plot(fft_freqs[:500], np.abs(fft_values[:500]))
plt.title("Frequency Spectrum (Fourier View)")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Strength")
plt.show()
