# Auto-generated companion snippet
# Source section: Chapter 11 - Oscillations in Nature: The Planet Breathes
# Paragraphs: 2328-2339
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Lotka-Volterra predator-prey model (simple, runnable, illustrative)
prey = 10.0
predator = 5.0
steps = 2000
dt = 0.01

prey_growth = 1.0        # alpha
predation_rate = 0.1     # beta
predator_efficiency = 0.075  # delta
predator_death = 1.5     # gamma

prey_history = []
predator_history = []

for _ in range(steps):
    d_prey = prey_growth * prey - predation_rate * prey * predator
    d_pred = predator_efficiency * prey * predator - predator_death * predator

    prey += dt * d_prey
    predator += dt * d_pred

    prey_history.append(prey)
    predator_history.append(predator)

plt.figure()
plt.plot(prey_history, label="Prey")
plt.plot(predator_history, label="Predator")
plt.legend()
plt.title("Predator-Prey Oscillations (Lotka-Volterra)")
plt.xlabel("Step")
plt.ylabel("Population (arbitrary units)")
plt.tight_layout()
plt.show()
