# Auto-generated companion snippet
# Source section: Chapter 10 - Nonlinear Worlds: Reality is Not a Straight Line
# Paragraphs: 2213-2216
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

t = np.linspace(0, 10, 500)
saturation = 1 - np.exp(-t)
import matplotlib.pyplot as plt

plt.plot(t, saturation)
