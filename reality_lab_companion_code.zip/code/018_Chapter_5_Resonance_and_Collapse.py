# Auto-generated companion snippet
# Source section: Chapter 5 - Resonance and Collapse
# Paragraphs: 1418-1421
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import numpy as np

t = np.linspace(0, 20, 1000)
amplified = np.exp(0.05 * t) * np.sin(0.7 * t); plt.plot(t, amplified); plt.title('Social Resonance: Amplification Over Time'); plt.xlabel('Time'); plt.ylabel('Collective Intensity'); plt.show()
