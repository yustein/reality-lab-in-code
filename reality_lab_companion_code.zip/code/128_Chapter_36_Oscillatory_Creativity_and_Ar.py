# Auto-generated companion snippet
# Source section: Chapter 36 - Oscillatory Creativity and Art
# Paragraphs: 5966-5976
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

size = 400
x = np.linspace(-5, 5, size)
y = np.linspace(-5, 5, size)
X, Y = np.meshgrid(x, y)
pattern = np.sin(X2 + Y2) + np.sin(3*X) * np.cos(3*Y)
plt.imshow(pattern)
plt.title("Generative Wave Interference Art")
plt.axis("off")
plt.show()
pattern = np.sin(2*X2 + Y2) + np.sin(5*X) * np.cos(Y)
