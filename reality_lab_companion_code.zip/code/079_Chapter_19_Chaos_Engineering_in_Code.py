# Auto-generated companion snippet
# Source section: Chapter 19 - Chaos Engineering in Code
# Paragraphs: 3570-3574
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

r_values = np.linspace(2.5, 4.0, 200)
final_values = []
for r in r_values:
    x = 0.2
    for i in range(200):
        x = logistic(r, x)
        final_values.append(x)
        plt.plot(r_values, final_values, ".")
        plt.title("Parameter Sweep: Stability to Chaos")
        plt.xlabel("r parameter")
        plt.ylabel("Final behavior")
        plt.show()
