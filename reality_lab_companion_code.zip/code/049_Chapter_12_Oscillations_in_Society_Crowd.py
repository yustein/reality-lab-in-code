# Auto-generated companion snippet
# Source section: Chapter 12 - Oscillations in Society: Crowds Have Frequencies
# Paragraphs: 2539-2541
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 20, 500)
wave = np.sin(t)
damped = np.exp(-0.1*t) * wave
plt.plot(t, damped)
plt.title("Damping Breaks the Social Wave")
plt.xlabel("Time")
plt.ylabel("Intensity")
plt.show()
