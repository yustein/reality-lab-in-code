# Auto-generated companion snippet
# Source section: Chapter 5 - Resonance and Collapse
# Paragraphs: 1355-1355
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

t = np.linspace(0, 50, 2000)
