# Auto-generated companion snippet
# Source section: Chapter 1 - The World is a Waveform
# Paragraphs: 767-767
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

y = 5 * np.sin(t)
