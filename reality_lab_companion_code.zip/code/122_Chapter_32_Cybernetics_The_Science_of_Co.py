# Auto-generated companion snippet
# Source section: Chapter 32 - Cybernetics: The Science of Control
# Paragraphs: 5539-5547
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

history = []
for step in range(50):
    error = target - state
    # Adaptive gain increases when error persists
    Kp += 0.001 * abs(error)

    control = Kp * error
    state += control
    history.append(state)
    plt.plot(history)
    plt.title("Adaptive Control Adjusts Its Own Strength")
    plt.xlabel("Step")
    plt.ylabel("State")
    plt.show()
