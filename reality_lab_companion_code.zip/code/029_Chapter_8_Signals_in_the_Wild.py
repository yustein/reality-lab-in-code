# Auto-generated companion snippet
# Source section: Chapter 8 - Signals in the Wild
# Paragraphs: 1910-1912
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

peaks = []
for i in range(1, len(clean)-1):
    if clean[i] > clean[i-1] and clean[i] > clean[i+1]:
        peaks.append(i)
        plt.plot(clean, label="Signal")
        plt.scatter(peaks, clean[peaks], color="red", label="Peaks")
        plt.legend()
        plt.title("Simple Peak Detection")
        plt.show()
