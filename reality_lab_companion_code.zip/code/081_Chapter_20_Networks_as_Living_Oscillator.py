# Auto-generated companion snippet
# Source section: Chapter 20 - Networks as Living Oscillators
# Paragraphs: 3716-3725
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

network = np.array([
[0, 1, 1, 0, 0],
[1, 0, 1, 1, 0],
[1, 1, 0, 0, 1],
[0, 1, 0, 0, 1],
[0, 0, 1, 1, 0]
])
state = np.array([1, 0, 0, 0, 0], dtype=float)
history = []
for step in range(20):
    state = network.dot(state)
    state = state / np.max(state) # normalize
    history.append(state.copy())
    history_array = np.array(history)
    for i in range(5):
        plt.plot(history_array[:, i], label=f"Node {i}")
        plt.legend()
        plt.title("Signal Diffusion Across Network")
        plt.xlabel("Time Step")
        plt.ylabel("Signal Strength")
        plt.show()
