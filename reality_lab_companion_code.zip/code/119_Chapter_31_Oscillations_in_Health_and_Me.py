# Auto-generated companion snippet
# Source section: Chapter 31 - Oscillations in Health and Medicine
# Paragraphs: 5361-5365
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


population = 0.2  # default initial state

history = []
for step in range(200):
    new_infected = spread_rate * infected * (population - infected)
    recovered = recovery_rate * infected
    infected += new_infected - recovered
    history.append(infected)
    plt.plot(history)
    plt.title("Epidemic Wave Dynamics")
    plt.xlabel("Time Step")
    plt.ylabel("Infected Individuals")
    plt.show()
