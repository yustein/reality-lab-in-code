# Auto-generated companion snippet
# Source section: Chapter 12 - Oscillations in Society: Crowds Have Frequencies
# Paragraphs: 2460-2460
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
