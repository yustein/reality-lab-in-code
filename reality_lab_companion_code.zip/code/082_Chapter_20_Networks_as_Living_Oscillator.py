# Auto-generated companion snippet
# Source section: Chapter 20 - Networks as Living Oscillators
# Paragraphs: 3739-3744
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

state = np.array([1, 1, 1, 1, 1], dtype=float)
history = []
for step in range(10):
    influence = network.dot(state)
    state = (influence > 1).astype(float)
    history.append(state.copy())
    print("Cascade states over time:")
    for step, s in enumerate(history):
        print(step, s)
