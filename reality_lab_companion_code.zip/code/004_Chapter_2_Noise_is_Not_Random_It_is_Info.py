# Auto-generated companion snippet
# Source section: Chapter 2 - Noise is Not Random, It is Information
# Paragraphs: 873-884
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")

import numpy as np
import matplotlib.pyplot as plt
noise = np.random.normal(0, 1, 500)
plt.plot(noise)
plt.title("White Noise")
plt.show()
