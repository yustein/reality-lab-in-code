# Auto-generated companion snippet
# Source section: Chapter 26 - Information Theory as Frequency Discipline
# Paragraphs: 4554-4568
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

p = np.array([0.5, 0.5])
entropy = -np.sum(p * np.log2(p))
print("Entropy:", entropy)
p2 = np.array([0.9, 0.1])
entropy2 = -np.sum(p2 * np.log2(p2))
print("Entropy:", entropy2)
samples = np.random.choice([0,1], size=1000, p=[0.5,0.5])
counts = np.bincount(samples) / len(samples)
import numpy as np

entropy_signal = -np.sum(counts * np.log2(counts))
