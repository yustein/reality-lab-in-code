# Auto-generated companion snippet
# Source section: Chapter 6 - Coupled Oscillators: When Systems Lock Together
# Paragraphs: 1549-1562
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt


freq2 = 0.051  # default frequency increment per step
coupling = 0.01  # default coupling strength
freq1 = 0.05  # default frequency increment per step

t = np.linspace(0, 50, 2000)
phase1 = 0
phase2 = 1
phase_history1 = []
phase_history2 = []
for i in range(len(t)):
    phase1 += freq1 + coupling * np.sin(phase2 - phase1)
    phase2 += freq2 + coupling * np.sin(phase1 - phase2)
    phase_history1.append(np.sin(phase1))
    phase_history2.append(np.sin(phase2))
    # plt.plot(t, phase_history1, label="Oscillator 1")
# plt.plot(t, phase_history2, label="Oscillator 2")
# plt.legend()
# plt.title("Coupled Oscillators Begin to Lock Together")
# plt.xlabel("Time")
# plt.ylabel("Amplitude")
# plt.show()

phase_history1 = np.array(phase_history1)
phase_history2 = np.array(phase_history2)
plt.figure()
plt.plot(t, phase_history1, label='Oscillator 1')
plt.plot(t, phase_history2, label='Oscillator 2')
plt.legend()
plt.title('Coupled Oscillators Begin to Lock Together')
plt.xlabel('Time')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()
