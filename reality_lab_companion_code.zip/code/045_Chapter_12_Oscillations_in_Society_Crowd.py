# Auto-generated companion snippet
# Source section: Chapter 12 - Oscillations in Society: Crowds Have Frequencies
# Paragraphs: 2483-2485
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


population = 0.2  # default initial state

history = []
for step in range(100):
    new_infected = spread_rate * infected * (population - infected)
    infected += new_infected
    history.append(infected)
    plt.plot(history)
    plt.title("Social Contagion Spread")
    plt.xlabel("Time Step")
    plt.ylabel("People Influenced")
    plt.show()
