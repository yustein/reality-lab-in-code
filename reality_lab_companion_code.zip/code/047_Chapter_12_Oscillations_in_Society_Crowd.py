# Auto-generated companion snippet
# Source section: Chapter 12 - Oscillations in Society: Crowds Have Frequencies
# Paragraphs: 2508-2512
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

t = np.linspace(0, 10, 500)
group1 = np.sin(t)
group2 = -np.sin(t)
import matplotlib.pyplot as plt

plt.plot(t, group1, label="Group 1")
