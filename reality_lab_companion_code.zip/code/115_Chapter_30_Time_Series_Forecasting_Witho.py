# Auto-generated companion snippet
# Source section: Chapter 30 - Time Series Forecasting Without Fantasy
# Paragraphs: 5236-5237
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

data2 = data.copy()
data2[700:] += 5 # sudden regime jump
plt.plot(data2)
plt.title("Regime Shift Breaks Forecast Assumptions")
plt.show()
