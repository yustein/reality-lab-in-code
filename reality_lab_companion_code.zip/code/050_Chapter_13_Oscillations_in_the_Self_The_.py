# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2575-2577
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# People treat states as identities.
# They mistake temporary oscillations for permanent truth.
# This chapter is about seeing the self correctly:
