# Auto-generated companion snippet
# Source section: Chapter 15 - Measurement as Philosophy
# Paragraphs: 2985-2986
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

drift = 0.01 * t
drifted_measurement = true_signal + drift + noise
plt.plot(true_signal, label="True")
plt.plot(drifted_measurement, label="Drifted Sensor Output")
plt.legend()
plt.title("Uncalibrated Drift Creates False Reality")
plt.show()
