# Auto-generated companion snippet
# Source section: Chapter 28 - Detecting Self-Deception With Code
# Paragraphs: 4822-4822
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
