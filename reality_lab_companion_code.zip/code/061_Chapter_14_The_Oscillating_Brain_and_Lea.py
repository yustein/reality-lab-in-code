# Auto-generated companion snippet
# Source section: Chapter 14 - The Oscillating Brain and Learning Systems
# Paragraphs: 2800-2806
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

value = -2.0
history = []
for step in range(50):
    error = target - value
    plt.plot(history)
    plt.title("Learning as Error-Correction Oscillation")
    plt.xlabel("Step")
    plt.ylabel("System Value")
    plt.show()
