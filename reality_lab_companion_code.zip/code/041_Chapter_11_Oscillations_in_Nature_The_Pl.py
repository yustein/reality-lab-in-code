# Auto-generated companion snippet
# Source section: Chapter 11 - Oscillations in Nature: The Planet Breathes
# Paragraphs: 2355-2357
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


r = 3.9  # default logistic-map parameter (chaotic regime)

history = []
for i in range(steps):
    population = population + r * population * (1 - population)
    history.append(population)
    plt.plot(history)
    plt.title("Resource Limits Create Oscillatory Stress")
    plt.xlabel("Time Step")
    plt.ylabel("Population Level")
    plt.show()
