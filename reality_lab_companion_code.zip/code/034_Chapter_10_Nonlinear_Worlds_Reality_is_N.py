# Auto-generated companion snippet
# Source section: Chapter 10 - Nonlinear Worlds: Reality is Not a Straight Line
# Paragraphs: 2157-2162
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Minimal runnable example: a simple (linear) mapping as a baseline.
k = 2.0
x = 3.0
y = k * x

print(f"k={k}, x={x}, y={y}")

plt.figure()
plt.bar(["x", "y"], [x, y])
plt.title("Baseline mapping: y = k*x")
plt.tight_layout()
plt.show()
