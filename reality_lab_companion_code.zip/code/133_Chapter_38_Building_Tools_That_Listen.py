# Auto-generated companion snippet
# Source section: Chapter 38 - Building Tools That Listen
# Paragraphs: 6237-6244
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

baseline = rolling_mean(stream)
residual = stream - baseline
threshold = 2 * np.std(residual)
anomalies = np.where(np.abs(residual) > threshold)[0]
plt.plot(stream, label="Signal")
plt.scatter(anomalies, stream[anomalies], label="Anomalies")
plt.legend()
plt.title("Noise Detector: Flagging Spikes Carefully")
plt.show()
