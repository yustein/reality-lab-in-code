# Auto-generated companion snippet
# Source section: Chapter 10 - Nonlinear Worlds: Reality is Not a Straight Line
# Paragraphs: 2229-2230
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

values = history[:-1]
next_values = history[1:]
plt.scatter(values, next_values, s=10)
plt.title("Phase Space View: Structure of Dynamics")
plt.xlabel("x_n")
plt.ylabel("x_{n+1}")
plt.show()
