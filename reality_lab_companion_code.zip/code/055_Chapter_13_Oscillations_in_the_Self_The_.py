# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2650-2657
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

behavior_A = 0
behavior_B = 0
choices = []
for step in range(100):
    if np.random.rand() < reward_A:
        behavior_A += 1
        choices.append("A")
    else:
        behavior_B += 1
        choices.append("B")
        plt.plot(np.cumsum([1 if c=="A" else 0 for c in choices]), label="Behavior A chosen")
        plt.title("Reinforcement Produces Behavioral Rhythm")
        plt.xlabel("Step")
        plt.ylabel("Cumulative Habit Strength")
        plt.show()
