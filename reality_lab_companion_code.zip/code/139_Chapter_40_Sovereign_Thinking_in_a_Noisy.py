# Auto-generated companion snippet
# Source section: Chapter 40 - Sovereign Thinking in a Noisy World
# Paragraphs: 6504-6508
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

signal = np.sin(np.linspace(0, 10, 500))
noise = np.random.normal(0, 0.8, 500)
mixed = signal + noise
window = 20
filtered = np.convolve(mixed, np.ones(window)/window, mode="same")
import matplotlib.pyplot as plt
plt.plot(mixed, alpha=0.3, label="Raw Noise World")
plt.plot(filtered, label="Filtered Signal")
plt.legend()
plt.title("Filtering as Mental Hygiene")
plt.show()
