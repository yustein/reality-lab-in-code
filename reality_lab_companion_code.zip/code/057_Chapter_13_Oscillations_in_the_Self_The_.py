# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2689-2691
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 30, 500)
energy = np.sin(0.2*t) * np.exp(-0.02*t)
plt.plot(t, energy)
plt.title("Energy Oscillation With Slow Depletion")
plt.xlabel("Time")
plt.ylabel("Energy Level")
plt.show()
