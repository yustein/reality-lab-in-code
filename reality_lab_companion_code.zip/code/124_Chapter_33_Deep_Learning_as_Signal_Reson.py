# Auto-generated companion snippet
# Source section: Chapter 33 - Deep Learning as Signal Resonance
# Paragraphs: 5610-5618
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np

x = np.array([1.0, 0.5, -1.2])
w = np.array([0.8, -0.3, 0.5])
z = np.dot(x, w)
def relu(v):
    return max(0, v)
    output = relu(z)
    print("Network output:", output)
