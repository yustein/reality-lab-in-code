# Auto-generated companion snippet
# Source section: Chapter 19 - Chaos Engineering in Code
# Paragraphs: 3522-3522
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
