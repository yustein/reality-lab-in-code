# Auto-generated companion snippet
# Source section: Chapter 21 - Time Delays and Hidden Instability
# Paragraphs: 3842-3855
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

delay_steps = 5
history = []
error_buffer = [0] * delay_steps
for step in range(50):
    error = target - state
    error_buffer.append(error)
    delayed_error = error_buffer.pop(0)

    state += gain * delayed_error
    history.append(state)
    plt.plot(history)
    plt.title("Delayed Feedback Creates Oscillation")
    plt.xlabel("Time Step")
    plt.ylabel("System State")
    plt.show()
