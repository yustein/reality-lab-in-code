# Auto-generated companion snippet
# Source section: Chapter 15 - Measurement as Philosophy
# Paragraphs: 2945-2951
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 500)
true_signal = np.sin(t)
noise = np.random.normal(0, 0.3, 500)
measured_signal = true_signal + noise
window = 20
cleaned_signal = np.convolve(measured_signal, np.ones(window)/window, mode="same")
plt.plot(true_signal, label="True Signal")
plt.plot(measured_signal, alpha=0.4, label="Measured (Noisy)")
plt.plot(cleaned_signal, label="Cleaned (Assumptions Added)")
plt.legend()
plt.title("Measurement Pipeline Adds Interpretation")
plt.show()
