# Auto-generated companion snippet
# Source section: Chapter 2 - Noise is Not Random, It is Information
# Paragraphs: 902-911
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 500)
signal = np.sin(t)
noisy_signal = signal + 0.5 * np.random.normal(0, 1, 500)
plt.plot(noisy_signal, label="Noisy Signal")
plt.title("Signal Buried in Noise")
plt.show()
window = 20
smoothed = np.convolve(noisy_signal, np.ones(window)/window, mode="same")
plt.plot(noisy_signal, alpha=0.4, label="Noisy")
plt.plot(smoothed, label="Smoothed")
plt.legend()
plt.title("Filtering Reveals Structure")
plt.show()
