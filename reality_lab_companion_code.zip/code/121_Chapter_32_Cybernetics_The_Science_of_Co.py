# Auto-generated companion snippet
# Source section: Chapter 32 - Cybernetics: The Science of Control
# Paragraphs: 5446-5446
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
