# Auto-generated companion snippet
# Source section: Chapter 12 - Oscillations in Society: Crowds Have Frequencies
# Paragraphs: 2525-2527
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0, 10, 500)
signal = np.sin(2*t)
amplified = (1 + 0.3*t) * signal
amplified = np.exp(0.05 * t) * np.sin(0.7 * t); plt.plot(t, amplified); plt.title('Social Resonance: Amplification Over Time'); plt.xlabel('Time'); plt.ylabel('Collective Intensity'); plt.show()
