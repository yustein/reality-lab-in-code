# Auto-generated companion snippet
# Source section: Chapter 5 - Resonance and Collapse
# Paragraphs: 1364-1369
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")


driving_freq = 1.5  # default driving frequency (Hz in normalized units)
natural_freq = 1.0  # default natural frequency (Hz in normalized units)

t = np.linspace(0, 10, 500)
import matplotlib.pyplot as plt
import numpy as np
y = np.sin(2 * np.pi * natural_freq * t) + 0.1 * np.sin(2 * np.pi * driving_freq * t)
plt.plot(t, y)
plt.title("Resonance: Small Driving Creates Large Motion")
plt.xlabel("Time")
plt.ylabel("Amplitude")
plt.show()
