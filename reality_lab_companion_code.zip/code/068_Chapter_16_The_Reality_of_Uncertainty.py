# Auto-generated companion snippet
# Source section: Chapter 16 - The Reality of Uncertainty
# Paragraphs: 3085-3095
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import numpy as np

samples = np.random.normal(0, 1, 1000)
import matplotlib.pyplot as plt

plt.hist(samples, bins=30)
np.random.seed(42)
samples1 = np.random.normal(0, 1, 5)
np.random.seed(42)
samples2 = np.random.normal(0, 1, 5)
print("Samples 1:", samples1)
print("Samples 2:", samples2)
