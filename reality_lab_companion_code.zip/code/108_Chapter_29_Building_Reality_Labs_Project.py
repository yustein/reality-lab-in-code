# Auto-generated companion snippet
# Source section: Chapter 29 - Building Reality Labs: Projects That Teach
# Paragraphs: 5019-5026
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

population = 500
informed = 1
history = []
for step in range(100):
    new_informed = spread_rate * informed * (population - informed)
    informed += new_informed
    history.append(informed)
    plt.plot(history)
    plt.title("Rumor Spread Dynamics")
    plt.xlabel("Time Step")
    plt.ylabel("People Informed")
    plt.show()
