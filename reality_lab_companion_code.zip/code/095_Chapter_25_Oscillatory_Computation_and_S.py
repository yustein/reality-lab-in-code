# Auto-generated companion snippet
# Source section: Chapter 25 - Oscillatory Computation and Signal Machines
# Paragraphs: 4442-4444
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

for step in range(1000):
    process_signal()
    if event_occurs:
        respond()
