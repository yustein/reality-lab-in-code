# Auto-generated companion snippet
# Source section: Chapter 29 - Building Reality Labs: Projects That Teach
# Paragraphs: 5064-5104
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")


r = 3.9  # default logistic-map parameter (chaotic regime)

history = []
for step in range(steps):
    optimism = 0.05 * (price - 1.0)
    momentum += optimism
    price += momentum

    # damping prevents infinite runaway
    import matplotlib.pyplot as plt

    momentum *= 0.95

    # history.append(price)
    history.append(x)
    x = r * x * (1 - x)
    for _ in range(steps):
        history = []
        steps = 200
        import matplotlib.pyplot as plt
        import numpy as np
        plt.plot(history); plt.title('Logistic map history'); plt.show()
        plt.title("Toy Market Cycle: Boom-Bust Feedback")
        plt.xlabel("Step")
        plt.ylabel("Price Level")
        plt.show()
        t = np.linspace(0, 10, 2000)
        weak = 0.2*np.sin(2*np.pi*3*t)
        noise = np.random.normal(0, 1, len(t))
        mixed = weak + noise
        import matplotlib.pyplot as plt

        plt.figure()
        mixed = np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 20 * t) + 0.2 * np.random.normal(0, 1, len(t))
        t = np.linspace(0, 2, 2000)
        import matplotlib.pyplot as plt
        import numpy as np
        plt.plot(t, mixed); plt.title('Mixed signal'); plt.show()
        plt.title("Weak Signal Buried in Noise")
        window = 50
        filtered = np.convolve(mixed, np.ones(window)/window, mode="same")
        plt.plot(t, filtered)
        plt.title("Recovered Signal After Filtering")
        plt.show()
