# Auto-generated companion snippet
# Source section: Chapter 27 - The Ethics of Modeling Reality
# Paragraphs: 4681-4681
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import numpy as np
import matplotlib.pyplot as plt
