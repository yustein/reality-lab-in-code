# Auto-generated companion snippet
# Source section: Chapter 16 - The Reality of Uncertainty
# Paragraphs: 3032-3033
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Open Terminal
# Type: conda activate realitylab (if needed)
