# Auto-generated companion snippet
# Source section: Chapter 8 - Signals in the Wild
# Paragraphs: 1928-1929
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

drift = 0.01 * time
drifted_signal = temperature + drift
plt.plot(time, temperature, label="True")
plt.plot(time, drifted_signal, label="Drifted Measurement")
plt.legend()
plt.title("Sensor Drift Creates False Trend")
plt.show()
