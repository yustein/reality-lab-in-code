# Auto-generated companion snippet
# Source section: Chapter 23 - Phase Transitions in Code
# Paragraphs: 4185-4187
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

import matplotlib
matplotlib.use("Agg")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

history = []
for step in range(100):
    recovery_rate = 0.1 - 0.0008 * step # slowing over time
    if recovery_rate < 0.01:
        recovery_rate = 0.01
        state += recovery_rate * (target - state)
        history.append(state)
        plt.plot(history)
        plt.title("Critical Slowing Down: Recovery Weakens Near Transition")
        plt.xlabel("Time Step")
        plt.ylabel("State")
        plt.show()
