# Auto-generated companion snippet
# Source section: Chapter 13 - Oscillations in the Self: The Human Interior is Dynamic
# Paragraphs: 2589-2591
# Notes:
# - Matplotlib uses Agg backend for headless runs.
# - Each file is meant to be runnable on its own.

# Open Terminal
# Type: conda activate realitylab (if needed)
# Type: jupyter notebook
